create function listofemployeeofsales(salesman character varying) returns SETOF employee
    language plpgsql
as
$$
DECLARE
	theemployee employee;
BEGIN
	FOR theemployee IN SELECT * FROM employee WHERE job=SALESMAN
	LOOP
		RETURN NEXT theemployee;
	END LOOP;
END;
$$;

alter function listofemployeeofsales(varchar) owner to postgres;

grant execute on function listofemployeeofsales(varchar) to anon;

grant execute on function listofemployeeofsales(varchar) to authenticated;

grant execute on function listofemployeeofsales(varchar) to service_role;

