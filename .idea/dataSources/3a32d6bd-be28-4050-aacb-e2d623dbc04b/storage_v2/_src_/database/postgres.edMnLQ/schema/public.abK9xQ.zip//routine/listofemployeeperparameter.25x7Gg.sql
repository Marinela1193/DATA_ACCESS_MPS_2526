create function listofemployeeperparameter(emp character varying) returns SETOF employee
    language plpgsql
as
$$ 
	DECLARE theemployee employee; 
BEGIN 
	FOR theemployee IN SELECT * FROM employee WHERE ename LIKE emp 
		LOOP 
			RETURN NEXT theemployee; 
		END LOOP; 
	END; 
$$;

alter function listofemployeeperparameter(varchar) owner to postgres;

grant execute on function listofemployeeperparameter(varchar) to anon;

grant execute on function listofemployeeperparameter(varchar) to authenticated;

grant execute on function listofemployeeperparameter(varchar) to service_role;

